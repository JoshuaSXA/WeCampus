create definer = root@localhost trigger quit
  after UPDATE
  on passenger
  for each row
BEGIN
	IF OLD.riding_status = 0 AND NEW.riding_status = 1 THEN
                             UPDATE carpool_case SET cur_num = cur_num - 1 WHERE carpool_id = NEW.carpool_id;
              ELSEIF OLD.riding_status = 0 AND NEW.riding_status = 2 THEN
                             UPDATE carpool_case SET cur_num = cur_num - 1 WHERE carpool_id = NEW.carpool_id;
	END IF;
END;

