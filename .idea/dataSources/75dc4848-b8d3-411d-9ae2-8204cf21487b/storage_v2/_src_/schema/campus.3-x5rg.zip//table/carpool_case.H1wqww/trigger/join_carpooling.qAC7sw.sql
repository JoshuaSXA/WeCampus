create definer = root@localhost trigger `join carpooling`
  before UPDATE
  on carpool_case
  for each row
BEGIN
	DECLARE msg VARCHAR(200);
              set msg = "passenger number exceeded!";
	IF NEW.cur_num > NEW.max_num THEN
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = msg;
              ELSEIF OLD.carpool_status = 0  AND NEW.cur_num = NEW.max_num THEN 
                            SET NEW.carpool_status = 1;
              ELSEIF OLD.carpool_status = 1 AND NEW.cur_num < NEW.max_num THEN
                            SET NEW.carpool_status = 0;
	END IF;
END;

