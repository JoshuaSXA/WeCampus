create definer = root@localhost trigger update_auth
  before UPDATE
  on student_auth
  for each row
BEGIN

	IF OLD.status = 2 AND NEW.status = 1 THEN
		UPDATE user SET name = NEW.name, student_id = NEW.student_id,  auth = 1 WHERE open_id = NEW.open_id;
              ELSEIF OLD.status = 2  AND NEW.status = 3 THEN 
                            UPDATE user SET auth = 3 WHERE open_id = NEW.open_id;
	END IF;
END;

