create definer = root@localhost trigger `template message`
  after UPDATE
  on carpool_case
  for each row
BEGIN
	INSERT IGNORE INTO template_message(open_id, module_tag, module_id, send_time, keyword_1, keyword_2, keyword_3) SELECT open_id, 'carpool', NEW.carpool_id, CONCAT(DATE_FORMAT(NOW(),'%Y-%m-%d'), ' 23:00'), (SELECT place_name FROM pick_up_place a WHERE a.place_id = NEW.start_place), (SELECT place_name FROM pick_up_place b WHERE b.place_id = NEW.end_place), NEW.start_time FROM passenger WHERE carpool_id = NEW.carpool_id AND riding_status=0;
              INSERT IGNORE INTO template_message(open_id, module_tag, module_id, send_time, keyword_1, keyword_2, keyword_3) SELECT NEW.creator, 'carpool', NEW.carpool_id, CONCAT(DATE_FORMAT(NOW(),'%Y-%m-%d'), ' 23:00'), (SELECT place_name FROM pick_up_place a WHERE a.place_id = NEW.start_place), (SELECT place_name FROM pick_up_place b WHERE b.place_id = NEW.end_place), NEW.start_time FROM carpool_case WHERE carpool_id = NEW.carpool_id;
END;

